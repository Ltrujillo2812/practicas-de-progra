﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica_2
{
	public partial class prac2 : Form
	{
		public prac2()
		{
			InitializeComponent();
		}

		private void button1_Click(object sender, EventArgs e)
		{
			try
			{
				int numero = Convert.ToInt32(textb1.Text);
				string Espartano = "";
				if (numero >= 1 && numero <= 10)
				{
					if (numero == 1)
					{
						Espartano = "I";
					}
					else if (numero == 2)
					{
						Espartano = "II";
					}
					else if (numero == 3)
					{
						Espartano = "III";
					}
					else if (numero == 4)
					{
						Espartano = "IV";
					}
					else if (numero == 5)
					{
						Espartano = "V";
					}
					else if (numero == 6)
					{
						Espartano = "VI";
					}
					else if (numero == 7)
					{
						Espartano = "VII";
					}
					else if (numero == 8)
					{
						Espartano = "VIII";
					}
					else if (numero == 9)
					{
						Espartano = "IX";
					}
					else
					{
						Espartano = "x";
					}
					lbEspartano.Text = "Equivale a " + Espartano + " en romano";

				}
				else
				{
					textb1.Focus();
					textb1.SelectAll();
					lbEspartano.Text = "Ingrese un número entre 1 y 10";
				}
			}
			catch (Exception)
			{
				textb1.Focus();
				textb1.SelectAll();
				lbEspartano.Text = "Error, favor ingrese solo numeros.";
			}
		}

		private void btn2_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
