﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica_N1_TM
{
	public partial class Form1 : Form
	{
		public Form1()
		{
			InitializeComponent();
		}

		private void btncalc_Click(object sender, EventArgs e)
		{
			double c1, c2, c3;
			//Txt1=c1, Txt2=c2, Txt3=c3
			c1 = Convert.ToDouble(txt1.Text);
			c2 = Convert.ToDouble(txt2.Text);
			c3 = Convert.ToDouble(txt3.Text);
			//Promedio = Txt4.Text
			txt4.Text = ((c1 + c2 + c3) / 3.0 ).ToString("N2");
		}

		private void txt1_TextChanged(object sender, EventArgs e)
		{
		}

		private void btnlimp_Click(object sender, EventArgs e)
		{
			txt1.Text = "";
			txt2.Text = "";
			txt3.Text = "";
			txt4.Text = "";
		}

		private void btnsal_Click(object sender, EventArgs e)
		{
			Close();
		}
	}
}
