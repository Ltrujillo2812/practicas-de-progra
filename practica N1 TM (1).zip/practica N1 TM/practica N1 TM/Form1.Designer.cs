﻿namespace practica_N1_TM
{
	partial class Form1
	{
		/// <summary>
		/// Variable del diseñador necesaria.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Limpiar los recursos que se estén usando.
		/// </summary>
		/// <param name="disposing">true si los recursos administrados se deben desechar; false en caso contrario.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Código generado por el Diseñador de Windows Forms

		/// <summary>
		/// Método necesario para admitir el Diseñador. No se puede modificar
		/// el contenido de este método con el editor de código.
		/// </summary>
		private void InitializeComponent()
		{
			this.LbExamen1 = new System.Windows.Forms.Label();
			this.LbExamen2 = new System.Windows.Forms.Label();
			this.LbExamen3 = new System.Windows.Forms.Label();
			this.txt1 = new System.Windows.Forms.TextBox();
			this.txt2 = new System.Windows.Forms.TextBox();
			this.txt3 = new System.Windows.Forms.TextBox();
			this.txt4 = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.btncalc = new System.Windows.Forms.Button();
			this.btnlimp = new System.Windows.Forms.Button();
			this.btnsal = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// LbExamen1
			// 
			this.LbExamen1.AutoSize = true;
			this.LbExamen1.Location = new System.Drawing.Point(49, 9);
			this.LbExamen1.Name = "LbExamen1";
			this.LbExamen1.Size = new System.Drawing.Size(57, 13);
			this.LbExamen1.TabIndex = 0;
			this.LbExamen1.Text = "Examen 1:";
			// 
			// LbExamen2
			// 
			this.LbExamen2.AutoSize = true;
			this.LbExamen2.Location = new System.Drawing.Point(49, 36);
			this.LbExamen2.Name = "LbExamen2";
			this.LbExamen2.Size = new System.Drawing.Size(57, 13);
			this.LbExamen2.TabIndex = 1;
			this.LbExamen2.Text = "Examen 2:";
			// 
			// LbExamen3
			// 
			this.LbExamen3.AutoSize = true;
			this.LbExamen3.Location = new System.Drawing.Point(49, 61);
			this.LbExamen3.Name = "LbExamen3";
			this.LbExamen3.Size = new System.Drawing.Size(57, 13);
			this.LbExamen3.TabIndex = 2;
			this.LbExamen3.Text = "Examen 3:";
			// 
			// txt1
			// 
			this.txt1.Location = new System.Drawing.Point(112, 6);
			this.txt1.Name = "txt1";
			this.txt1.Size = new System.Drawing.Size(100, 20);
			this.txt1.TabIndex = 3;
			this.txt1.TextChanged += new System.EventHandler(this.txt1_TextChanged);
			// 
			// txt2
			// 
			this.txt2.Location = new System.Drawing.Point(112, 33);
			this.txt2.Name = "txt2";
			this.txt2.Size = new System.Drawing.Size(100, 20);
			this.txt2.TabIndex = 4;
			// 
			// txt3
			// 
			this.txt3.Location = new System.Drawing.Point(112, 58);
			this.txt3.Name = "txt3";
			this.txt3.Size = new System.Drawing.Size(100, 20);
			this.txt3.TabIndex = 5;
			// 
			// txt4
			// 
			this.txt4.Location = new System.Drawing.Point(112, 97);
			this.txt4.Name = "txt4";
			this.txt4.ReadOnly = true;
			this.txt4.Size = new System.Drawing.Size(100, 20);
			this.txt4.TabIndex = 7;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(49, 100);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(57, 13);
			this.label4.TabIndex = 6;
			this.label4.Text = "Promedio: ";
			// 
			// btncalc
			// 
			this.btncalc.Location = new System.Drawing.Point(12, 137);
			this.btncalc.Name = "btncalc";
			this.btncalc.Size = new System.Drawing.Size(75, 23);
			this.btncalc.TabIndex = 8;
			this.btncalc.Text = "Calcular";
			this.btncalc.UseVisualStyleBackColor = true;
			this.btncalc.Click += new System.EventHandler(this.btncalc_Click);
			this.btncalc.Enter += new System.EventHandler(this.btncalc_Click);
			// 
			// btnlimp
			// 
			this.btnlimp.Location = new System.Drawing.Point(93, 137);
			this.btnlimp.Name = "btnlimp";
			this.btnlimp.Size = new System.Drawing.Size(75, 23);
			this.btnlimp.TabIndex = 9;
			this.btnlimp.Text = "Limpiar";
			this.btnlimp.UseVisualStyleBackColor = true;
			this.btnlimp.Click += new System.EventHandler(this.btnlimp_Click);
			// 
			// btnsal
			// 
			this.btnsal.Location = new System.Drawing.Point(174, 137);
			this.btnsal.Name = "btnsal";
			this.btnsal.Size = new System.Drawing.Size(75, 23);
			this.btnsal.TabIndex = 10;
			this.btnsal.Text = "Salir";
			this.btnsal.UseVisualStyleBackColor = true;
			this.btnsal.Click += new System.EventHandler(this.btnsal_Click);
			// 
			// Form1
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(257, 170);
			this.Controls.Add(this.btnsal);
			this.Controls.Add(this.btnlimp);
			this.Controls.Add(this.btncalc);
			this.Controls.Add(this.txt4);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.txt3);
			this.Controls.Add(this.txt2);
			this.Controls.Add(this.txt1);
			this.Controls.Add(this.LbExamen3);
			this.Controls.Add(this.LbExamen2);
			this.Controls.Add(this.LbExamen1);
			this.Name = "Form1";
			this.Text = "Promedio de examenes";
			this.Enter += new System.EventHandler(this.btncalc_Click);
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label LbExamen1;
		private System.Windows.Forms.Label LbExamen2;
		private System.Windows.Forms.Label LbExamen3;
		private System.Windows.Forms.TextBox txt1;
		private System.Windows.Forms.TextBox txt2;
		private System.Windows.Forms.TextBox txt3;
		private System.Windows.Forms.TextBox txt4;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Button btncalc;
		private System.Windows.Forms.Button btnlimp;
		private System.Windows.Forms.Button btnsal;
	}
}

