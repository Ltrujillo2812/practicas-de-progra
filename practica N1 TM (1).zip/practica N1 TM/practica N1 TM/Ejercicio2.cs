﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace practica_N1_TM
{
	public partial class Ejercicio2 : Form
	{
		public Ejercicio2()
		{
			InitializeComponent();
		}

		private void btncalc_Click(object sender, EventArgs e)
		{
			txtBin.Text = Convert.ToString(Convert.ToInt32(txtdec.Text), 2);
			txtOct.Text = Convert.ToString(Convert.ToInt32(txtdec.Text), 8);
			txtHex.Text = Convert.ToString(Convert.ToInt32(txtdec.Text), 16);
		}

		private void btnlimp_Click(object sender, EventArgs e)
		{
			txtdec.Text = "";
			txtBin.Text = "";
			txtOct.Text = "";
			txtHex.Text = "";
		}
	}
}
