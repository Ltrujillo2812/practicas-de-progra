﻿namespace practica_N1_TM
{
	partial class Ejercicio2
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.IContainer components = null;

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		/// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
		protected override void Dispose(bool disposing)
		{
			if (disposing && (components != null))
			{
				components.Dispose();
			}
			base.Dispose(disposing);
		}

		#region Windows Form Designer generated code

		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.label1 = new System.Windows.Forms.Label();
			this.txtdec = new System.Windows.Forms.TextBox();
			this.groupBox1 = new System.Windows.Forms.GroupBox();
			this.txtBin = new System.Windows.Forms.TextBox();
			this.label2 = new System.Windows.Forms.Label();
			this.txtHex = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.txtOct = new System.Windows.Forms.TextBox();
			this.label4 = new System.Windows.Forms.Label();
			this.btnsal = new System.Windows.Forms.Button();
			this.btnlimp = new System.Windows.Forms.Button();
			this.btncalc = new System.Windows.Forms.Button();
			this.groupBox1.SuspendLayout();
			this.SuspendLayout();
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(12, 9);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(51, 13);
			this.label1.TabIndex = 0;
			this.label1.Text = "Decimal: ";
			// 
			// txtdec
			// 
			this.txtdec.Location = new System.Drawing.Point(69, 6);
			this.txtdec.Name = "txtdec";
			this.txtdec.Size = new System.Drawing.Size(100, 20);
			this.txtdec.TabIndex = 1;
			// 
			// groupBox1
			// 
			this.groupBox1.Controls.Add(this.txtOct);
			this.groupBox1.Controls.Add(this.label4);
			this.groupBox1.Controls.Add(this.txtHex);
			this.groupBox1.Controls.Add(this.label3);
			this.groupBox1.Controls.Add(this.txtBin);
			this.groupBox1.Controls.Add(this.label2);
			this.groupBox1.Location = new System.Drawing.Point(13, 40);
			this.groupBox1.Name = "groupBox1";
			this.groupBox1.Size = new System.Drawing.Size(219, 101);
			this.groupBox1.TabIndex = 2;
			this.groupBox1.TabStop = false;
			this.groupBox1.Text = "Equivale a: ";
			// 
			// txtBin
			// 
			this.txtBin.Location = new System.Drawing.Point(100, 19);
			this.txtBin.Name = "txtBin";
			this.txtBin.ReadOnly = true;
			this.txtBin.Size = new System.Drawing.Size(100, 20);
			this.txtBin.TabIndex = 3;
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(11, 22);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(45, 13);
			this.label2.TabIndex = 2;
			this.label2.Text = "Binario: ";
			// 
			// txtHex
			// 
			this.txtHex.Location = new System.Drawing.Point(100, 71);
			this.txtHex.Name = "txtHex";
			this.txtHex.ReadOnly = true;
			this.txtHex.Size = new System.Drawing.Size(100, 20);
			this.txtHex.TabIndex = 5;
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(11, 74);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(71, 13);
			this.label3.TabIndex = 4;
			this.label3.Text = "Hexadecimal:";
			// 
			// txtOct
			// 
			this.txtOct.Location = new System.Drawing.Point(100, 45);
			this.txtOct.Name = "txtOct";
			this.txtOct.ReadOnly = true;
			this.txtOct.Size = new System.Drawing.Size(100, 20);
			this.txtOct.TabIndex = 7;
			// 
			// label4
			// 
			this.label4.AutoSize = true;
			this.label4.Location = new System.Drawing.Point(11, 48);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(38, 13);
			this.label4.TabIndex = 6;
			this.label4.Text = "Octal: ";
			// 
			// btnsal
			// 
			this.btnsal.Location = new System.Drawing.Point(175, 147);
			this.btnsal.Name = "btnsal";
			this.btnsal.Size = new System.Drawing.Size(75, 23);
			this.btnsal.TabIndex = 13;
			this.btnsal.Text = "Salir";
			this.btnsal.UseVisualStyleBackColor = true;
			// 
			// btnlimp
			// 
			this.btnlimp.Location = new System.Drawing.Point(94, 147);
			this.btnlimp.Name = "btnlimp";
			this.btnlimp.Size = new System.Drawing.Size(75, 23);
			this.btnlimp.TabIndex = 12;
			this.btnlimp.Text = "Limpiar";
			this.btnlimp.UseVisualStyleBackColor = true;
			this.btnlimp.Click += new System.EventHandler(this.btnlimp_Click);
			// 
			// btncalc
			// 
			this.btncalc.Location = new System.Drawing.Point(13, 147);
			this.btncalc.Name = "btncalc";
			this.btncalc.Size = new System.Drawing.Size(75, 23);
			this.btncalc.TabIndex = 11;
			this.btncalc.Text = "Calcular";
			this.btncalc.UseVisualStyleBackColor = true;
			this.btncalc.Click += new System.EventHandler(this.btncalc_Click);
			// 
			// Ejercicio2
			// 
			this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
			this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
			this.ClientSize = new System.Drawing.Size(264, 180);
			this.Controls.Add(this.btnsal);
			this.Controls.Add(this.btnlimp);
			this.Controls.Add(this.btncalc);
			this.Controls.Add(this.groupBox1);
			this.Controls.Add(this.txtdec);
			this.Controls.Add(this.label1);
			this.Name = "Ejercicio2";
			this.Text = "Ejercicio2";
			this.groupBox1.ResumeLayout(false);
			this.groupBox1.PerformLayout();
			this.ResumeLayout(false);
			this.PerformLayout();

		}

		#endregion

		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox txtdec;
		private System.Windows.Forms.GroupBox groupBox1;
		private System.Windows.Forms.TextBox txtOct;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.TextBox txtHex;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.TextBox txtBin;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Button btnsal;
		private System.Windows.Forms.Button btnlimp;
		private System.Windows.Forms.Button btncalc;
	}
}